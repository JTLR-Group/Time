<?php

return array(
    
    'secretKey' => '_put_your_random_string_here_',
    'requestFilterType' => FILTER_SANITIZE_STRING
);