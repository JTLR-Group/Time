<!DOCTYPE html>
<html>
<head>
    <title><?php echo $title;?></title>
    <link rel="stylesheet" href="<?php echo $this->uri->baseUri;?>assets/css/main.css" type="text/css" media="screen" />
</head>