<a href="https://twitter.com/share" class="twitter-share-button" data-text="How much time you've wasted watching TV shows:" data-url="http://timewasted.co.uk" data-count="horizontal" data-via="sican">Tweet</a><script type="text/javascript" src="//platform.twitter.com/widgets.js"></script>

<div class="gbutton"><div class="g-plusone" data-size="medium" data-href="http://timewasted.co.uk"></div></div>

<script type="text/javascript">
	//for +1 button
	(function() {
		var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
		po.src = 'https://apis.google.com/js/plusone.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
	})();
</script>

<div class="fb-like"><iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Ftimewasted.co.uk&amp;send=false&amp;layout=button_count&amp;width=150&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=21&amp;appId=224570947600766" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:150px; height:21px;" allowTransparency="true"></iframe></div>
<br/>